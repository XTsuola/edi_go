# Filter

模型库 - Filter Component Model Library

## 概述

本库包含滤波器组件的模型定义和符号。

## 库信息

- **名称**: Filter.V.1.0
- **版本**: 1.0.0
- **作者**: star
- **创建时间**: 2026-04-22T06:29:17Z
- **UUID**: 463d1b39-46e1-4e3f-b12d-6e70d4381b28

## 描述

filter model library


## 目录结构

```
Filter/
├── sym/                              # 符号目录
│   └── [UUID]/                       # 符号子目录(以UUID命名)
│       ├── .bm-sym                   # 符号标记文件
│       └── symbol.ep                 # 符号定义文件
├── cmp/                              # 模型组件目录
│   └── [UUID]/                       # 模型子目录(以UUID命名)
│       ├── component.ep              # 组件定义文件
│       ├── .bm-cmp                   # 组件标记文件
│       └── dep/                      # 组件依赖目录
├── .bm-lib                           # 库标记文件
├── library.ep                        # 库配置文件
└── README.md                         # 使用说明文档
```

## 文件说明

### library.ep

库的主配置文件,采用Lisp格式:

```lisp
(bm_library 463d1b39-46e1-4e3f-b12d-6e70d4381b28
 (name "Filter.V.1.0")
 (description "filter model library")
 (keywords "amplifier, GaAs, MMIC")
 (author "star")
 (version "1.0.0")
 (created 2026-04-22T06:29:17Z)
 (url "")
)
```

### .bm-lib

库标记文件,值为 `1`,用于标识这是一个有效的模型库目录。

## 统计信息

- **符号数量**: 3
- **组件数量**: 101
- **库版本**: 1.0.0
- **创建时间**: 2026-04-22T06:29:17Z

---

*本文档由自动打包工具生成于 2026-04-22*
