# Filter_HaoHan_5_12

模型库 - Filter Component Model Library

## 概述

本库包含射频器件组件的模型定义和符号。

## 库信息

- **名称**: Filter_HaoHan_5_12.V.1.0
- **版本**: 1
- **作者**: 
- **创建时间**: 2026-05-12T02:37:39Z
- **UUID**: 3ac3449e-1ea5-440a-876a-0846fac8ce6a


## 目录结构

```
Filter_HaoHan_5_12/
├── sym/                              # 符号目录
│   └── [UUID]/                       # 符号子目录(以UUID命名)
│       ├── .bm-sym                   # 符号标记文件
│       └── symbol.ep                 # 符号定义文件
├── cmp/                              # 模型组件目录
│   └── [UUID]/                       # 模型子目录(以UUID命名)
│       ├── component.ep              # 组件定义文件
│       ├── .bm-cmp                   # 组件标记文件
│       └── dep/                      # 组件依赖目录
├── .bm-lib                           # 库标记文件
├── library.ep                        # 库配置文件
└── README.md                         # 使用说明文档
```

## 文件说明

### library.ep

库的主配置文件,采用Lisp格式:

```lisp
(bm_library 3ac3449e-1ea5-440a-876a-0846fac8ce6a
 (name "Filter_HaoHan_5_12.V.1.0")
 (description "")
 (keywords "")
 (author "")
 (version "1")
 (created 2026-05-12T02:37:39Z)
 (url "")
)
```

### .bm-lib

库标记文件,值为 `1`,用于标识这是一个有效的模型库目录。

## 统计信息

- **符号数量**: 2
- **组件数量**: 36
- **库版本**: 1
- **创建时间**: 2026-05-12T02:37:39Z

---

*本文档由自动打包工具生成于 2026-05-12*
